<?php
// final_project/includes/footer.php
?>
<footer style="margin-top:28px;padding:20px 0;color:#666;background:transparent;border-top:1px solid #f0f0f0">
  <div class="container">
    <small>Attendance System — demo. &copy; <?php echo date('Y'); ?></small>
  </div>
</footer>
<script src="/tp_web/final_project/public/js/main.js"></script>
</body>
</html>
