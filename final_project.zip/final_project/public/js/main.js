// final_project/public/js/main.js
document.addEventListener('DOMContentLoaded', function() {
  // future interactivity here (search, filter, etc.)
  console.log('Main script loaded');
});
