<?php
// final_project/public/index.php
header('Location: /tp_web/final_project/public/login.php');
exit;
